/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package equipwise;

//IMPORTS
import ADTs.ItemBST;
import java.awt.CardLayout;
import equipwise.BrowseUI;
import equipwise.PurchaseUI;
import ADTs.ItemList;
import ADTs.ItemNode;
import ADTs.OrderQueue;


/**
 *
 * @author ImaanAhmed
 */
public class MainFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MainFrame.class.getName());

    /**
     * Creates new form MainFrame
     */
    
    //DECLARING VARIABLES FOR UI
    private ItemList itemList;  //Adding items list to main frame
    private BrowseUI browseUI;  //Adding ADT 1 to main frame
    private PurchaseUI purchaseUI;  //Adding ADT 2 to main frame
    private OrderQueue orderQueue;  //Adding ADT 3 to main frame
    private AddUpdateUI addUpdateUI;    //Adding panel for users to add/update items & SLL
    private ItemBST bst;    //storing BST for searching and updating BST
    
    CardLayout layout;  //card layout
    
    //CONSTRUCTOR (auto-generated)
    public MainFrame() {
        initComponents();
        
        layout = (CardLayout) mainPanel.getLayout();
        
        //CREATE ITEM DATA
        itemList = new ItemList();
        //CREATING Q
        orderQueue = new OrderQueue();
        //BST
        bst = new ItemBST();
        
        
        //ADD ITEMS
        itemList.insert(new Item(1, "Bow", 59, "Good", "UCD Archery",
                "https://th.bing.com/th/id/R.140c3c7bafba6ae12ced7ceb28373948?rik=2pYBp87RBd99Og&pid=ImgRaw&r=0"));
        itemList.insert(new Item(2, "Arrows", 34, "New", "DCU Archery",
                "https://i5.walmartimages.com/seo/GPP-12PK-28-Fiberglass-Archery-Target-Arrows-Practice-Arrow-or-Youth-Arrow-for-Recurve-Bow-Green-Yellow-Vanes_862a87e9-5eac-4ace-be9f-e9b1aeddea71.49fc1c2588e85d9b63ca4e3e794558e4.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"));
        itemList.insert(new Item(3, "Target", 120, "Used", "NCI Archers",
                "https://th.bing.com/th/id/R.b939f0e905897455b8a8f10650339682?rik=dd77TXNy8s%2fR%2fg&pid=ImgRaw&r=0"));
        itemList.insert(new Item(1, "Bow", 59, "Good", "UCD Archery",
                "https://th.bing.com/th/id/R.140c3c7bafba6ae12ced7ceb28373948?rik=2pYBp87RBd99Og&pid=ImgRaw&r=0"));
        itemList.insert(new Item(2, "Arrows", 34, "New", "DCU Archery",
                "https://i5.walmartimages.com/seo/GPP-12PK-28-Fiberglass-Archery-Target-Arrows-Practice-Arrow-or-Youth-Arrow-for-Recurve-Bow-Green-Yellow-Vanes_862a87e9-5eac-4ace-be9f-e9b1aeddea71.49fc1c2588e85d9b63ca4e3e794558e4.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"));
        itemList.insert(new Item(3, "Target", 120, "Used", "NCI Archers",
                "https://th.bing.com/th/id/R.b939f0e905897455b8a8f10650339682?rik=dd77TXNy8s%2fR%2fg&pid=ImgRaw&r=0"));
        itemList.insert(new Item(1, "Bow", 59, "Good", "UCD Archery",
                "https://th.bing.com/th/id/R.140c3c7bafba6ae12ced7ceb28373948?rik=2pYBp87RBd99Og&pid=ImgRaw&r=0"));
        itemList.insert(new Item(2, "Arrows", 34, "New", "DCU Archery",
                "https://i5.walmartimages.com/seo/GPP-12PK-28-Fiberglass-Archery-Target-Arrows-Practice-Arrow-or-Youth-Arrow-for-Recurve-Bow-Green-Yellow-Vanes_862a87e9-5eac-4ace-be9f-e9b1aeddea71.49fc1c2588e85d9b63ca4e3e794558e4.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"));
        itemList.insert(new Item(3, "Target", 120, "Used", "NCI Archers",
                "https://th.bing.com/th/id/R.b939f0e905897455b8a8f10650339682?rik=dd77TXNy8s%2fR%2fg&pid=ImgRaw&r=0"));
        
        
        //Adding items to BST:
        ItemNode current = itemList.getHead();
        while(current!= null){
            bst.insert((Item) current.getData());
            current =current.getNext();
        }
        
        
        //CONNECTING CARD LAYOUT
        browseUI = new BrowseUI(this, itemList, bst);  //creating panel & items
        purchaseUI = new PurchaseUI(this, orderQueue, itemList);  //creating panel
        //CONNECTING USERS ADD PANEL
        addUpdateUI = new AddUpdateUI(this, itemList);
        
        //ADDING PANELS TO CARD LAYOUT
        mainPanel.add(browseUI, "browse");
        mainPanel.add(purchaseUI, "purchase");
        mainPanel.add(addUpdateUI, "add");
        
        //DEFAULT SCREEN
        layout.show(mainPanel, "browse");
        
        
    }
    
    
    //Methods to switch between panels
    public void showBrowse() {
        ((CardLayout) mainPanel.getLayout()).show(mainPanel, "browse");
    }
    public void showPurchase(Item item) {
        purchaseUI.setItem(item);
        ((CardLayout) mainPanel.getLayout()).show(mainPanel, "purchase");
    }
    public void showAddUpdate() {
        layout.show(mainPanel, "add");
    }
    
    //REFRESHING BROWSEUI (for when user adds items)
    public void refreshBrowse() {
        browseUI.loadItems();
    }
    
    //Getter for BST
    public ItemBST getBST() {
        return bst;
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(400, 600));
        setSize(new java.awt.Dimension(0, 0));
        getContentPane().setLayout(new java.awt.CardLayout());

        mainPanel.setMinimumSize(new java.awt.Dimension(0, 0));
        mainPanel.setLayout(new java.awt.CardLayout());
        getContentPane().add(mainPanel, "card2");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MainFrame().setVisible(true));
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel mainPanel;
    // End of variables declaration//GEN-END:variables
}
