/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ADTs;

//IMPORTS
import equipwise.Item;
import equipwise.ItemOperations;

/**
 *
 * @author ImaanAhmed
 */
public class ItemBST implements ItemOperations{
    
    private TreeNode root;    //

    //CONSTRUCTOR
    public ItemBST() {
        root = null;
    }
    
    
    //APPLYING INSERT METHOD
    @Override
    public void insert(Item item) {
        root = insertRec(root, item);
    }
    
    //METHOD TO INSERT
    private TreeNode insertRec(TreeNode current, Item item) {
        //Creates a new node when an empty position is found
        if(current == null) {
            return new TreeNode(item);
        }
        
        //Comparing by ID
        if(item.getId() < current.getData().getId()) {  //determines whether the item goes to the left or right subtree
            current.setLeft(insertRec(current.getLeft(), item));
        } else {
            current.setRight(insertRec(current.getRight(), item));
        } //end if/else statement
        
        return current;     //
    } //end insertRec
    
    
    //RETURNING SEARCH METHOD
    @Override
    public Item search(String name) {
        return searchRec(root, name);
    } //end search()
    
    //METHOD TO SEARCH (by name)
    private Item searchRec(TreeNode current, String name) {
        
        if(current == null) return null;    //
        //
        if(current.getData().getName().equalsIgnoreCase(name)) {    //Checks if the current node matches the search input
            return current.getData();
        }
        //Sesarching on both sides since BST is ordered by ID, not name
        Item found = searchRec(current.getLeft(), name);    //Recursively searching the left subtree first
        if(found != null) return found;
        
        return searchRec(current.getRight(), name); //If nothing found searches the right subtree
        
    } //end searchRec
    //Beacuase the BST is ordered by ID & not Name, I traverse the entire tree.
    
    
    //APPLYING DELETE METHOD
    @Override
    public void delete(int id) {
        root = deleteRec(root, id);
    }
    
    
    //METHOD TO DELETE (by ID)
    private TreeNode deleteRec(TreeNode current, int id) {
        
        if(current == null) return null;    //
        //
        if(id < current.getData().getId()) {
            current.setLeft(deleteRec(current.getLeft(), id));
        } else if(id > current.getData().getId()) {
            current.setRight(deleteRec(current.getRight(), id));
        } else {    //when node not found
            
            //Case 1: No child
            if(current.getLeft() == null && current.getRight() == null) {
                return null;
            }//REMOVES THE LEAF NODE
            
            //Case 2: One child only
            if(current.getLeft() == null) {
                return current.getRight();
            } else if(current.getRight() == null) {
                return current.getLeft();
            }//REPLACES THE NODE WITH ITS CHILD
            
            //Case 3: Two child nodes
            Item smallest = findMin(current.getRight());    //
            current.setData(smallest);      //
            current.setRight(deleteRec(current.getRight(), smallest.getId()));  //
            //REPLACES THE NODE WIH THE SMALLEST VALUE IN THE RIGHT SUBTREE
        }
        
        return current;
    }
    
    //
    private Item findMin(TreeNode node) {
        
        //KEEPS MOVING TO THE LEFT TO FIND THE SMALLEST VALUE
        while(node.getLeft() != null) {
            node = node.getLeft();
        } //end while loop
        
        return node.getData();
                
    } //end findMin()
    
    
    //RETURNING METHOD TO DISPLAY IN-ORDER
    @Override
    public void display() {
        inorder(root);
    }
    
    //DISPLAY METHOD (in-order traversal)
    private void inorder(TreeNode node) {
        //IN-ORDER TRAVERAL PRINTS ITEMS IN SORTED ORDER
        if(node != null) {
            inorder(node.getLeft());
            System.out.println(node.getData().displayInfo());
            inorder(node.getRight());
        } //end if statement
        
    } //end inorder()
    
    
} //end class

/*
BST is ordered by ID but searches by name... Order by name next time

HOW ALL ADTs CONNECT?
SLL stores all items (dynamic storage)
BST provides searching functionality (explore efficient searching)
Q handles order processing (like real-world orders)
*/
